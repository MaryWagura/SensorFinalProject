import numpy as np
import cv2 as cv

cap = cv.VideoCapture(1)
if not cap.isOpened():
    print("Cannot open camera")
    exit()
ret, frame = cap.read()

if ret:
    #gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    cv.imwrite('captured_image4.png', frame)
    print("Image captured")

cap.release()